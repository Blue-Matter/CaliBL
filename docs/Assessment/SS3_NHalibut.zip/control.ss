#V3.30.14.00-safe;_2019_07_19;_Stock_Synthesis_by_Richard_Methot_(NOAA)_using_ADMB_12.0

0  # 0 means do not read wtatage.ss; 1 means read and use wtatage.ss and also read and use growth parameters
1  #_N_Growth_Patterns (Growth Patterns, Morphs, Bio Patterns, GP are terms used interchangeably in SS)
1 #_N_platoons_Within_GrowthPattern 
#_Cond 1 #_Platoon_between/within_stdev_ratio (no read if N_platoons=1)
#_Cond  1 #vector_platoon_dist_(-1_in_first_val_gives_normal_approx)
#
4 # recr_dist_method for parameters:  2=main effects for GP, Area, Settle timing; 3=each Settle entity; 4=none (only when N_GP*Nsettle*pop==1)
1 # not yet implemented; Future usage: Spawner-Recruitment: 1=global; 2=by area
1 # number of recruitment settlement assignments 
0 # unused option
#GPattern month  area  age (for each settlement assignment)
 1 1 1 0 ### 
#
#_Cond 0 # N_movement_definitions goes here if Nareas > 1
#_Cond 1.0 # first age that moves (real age at begin of season, not integer) also cond on do_migration>0
#_Cond 1 1 1 2 4 10 # example move definition for seas=1, morph=1, source=1 dest=2, age1=4, age2=10
#

1 #_Nblock_Patterns
1 #_blocks_per_pattern 
# begin and end years of blocks
1980 1996
#

# controls for all timevary parameters 
1 #_env/block/dev_adjust_method for all time-vary parms (1=warn relative to base parm bounds; 3=no bound check)
#
# AUTOGEN
1 1 1 1 1 # autogen: 1st element for biology, 2nd for SR, 3rd for Q, 4th reserved, 5th for selex
# where: 0 = autogen all time-varying parms; 1 = read each time-varying parm line; 2 = read then autogen if parm min==-12345
#
#_Available timevary codes
#_Block types: 0: P_block=P_base*exp(TVP); 1: P_block=P_base+TVP; 2: P_block=TVP; 3: P_block=P_block(-1) + TVP
#_Block_trends: -1: trend bounded by base parm min-max and parms in transformed units (beware); -2: endtrend and infl_year direct values; -3: end and infl as fraction of base range
#_EnvLinks:  1: P(y)=P_base*exp(TVP*env(y));  2: P(y)=P_base+TVP*env(y);  3: null;  4: P(y)=2.0/(1.0+exp(-TVP1*env(y) - TVP2))
#_DevLinks:  1: P(y)*=exp(dev(y)*dev_se;  2: P(y)+=dev(y)*dev_se;  3: random walk;  4: zero-reverting random walk with rho;  21-24 keep last dev for rest of years
#
#_Prior_codes:  0=none; 6=normal; 1=symmetric beta; 2=CASAL's beta; 3=lognormal; 4=lognormal with biascorr; 5=gamma
#
# setup for M, growth, maturity, fecundity, recruitment distibution, movement 
#

0 #_natM_type:_0=1Parm; 1=N_breakpoints;_2=Lorenzen;_3=agespecific;_4=agespec_withseasinterpolate
  #_no additional input for selected M option; read 1P per morph
#
1 # GrowthModel: 1=vonBert with L1&L2; 2=Richards with L1&L2; 3=age_specific_K_incr; 4=age_specific_K_decr; 5=age_specific_K_each; 6=NA; 7=NA; 8=growth cessation
1 #_Age(post-settlement)_for_L1;linear growth below this
15 #25 #_Growth_Age_for_L2 (999 to use as Linf)
-999 #_exponential decay for growth above maxage (value should approx initial Z; -999 replicates 3.24; -998 to not allow growth above maxage)
0  #_placeholder for future growth feature
#
0 #_SD_add_to_LAA (set to 0.1 for SS2 V1.x compatibility)
2 #0 #_CV_Growth_Pattern:  0 CV=f(LAA); 1 CV=F(A); 2 SD=F(LAA); 3 SD=F(A); 4 logSD=F(A)   ###flag as potential area for adjusting - switch to SD (opt 2) to avoid large variance at young ages????
#
1 #_maturity_option:  1=length logistic; 2=age logistic; 3=read age-maturity matrix by growth_pattern; 4=read age-fecundity; 5=disabled; 6=read length-maturity
3 #_First_Mature_Age
1 #_fecundity option:(1)eggs=Wt*(a+b*Wt);(2)eggs=a*L^b;(3)eggs=a*Wt^b; (4)eggs=a+b*L; (5)eggs=a+b*W
0 #_hermaphroditism option:  0=none; 1=female-to-male age-specific fxn; -1=male-to-female age-specific fxn
1 #_parameter_offset_approach (1=none, 2= M, G, CV_G as offset from female-GP1, 3=like SS2 V1.x)
#

## FEMALE BIOLOGY
#_growth_parms
#_ LO	HI	INIT	PRIOR 	PR_SD 	PR_type PHASE 	env_var&link dev_link dev_minyr dev_maxyr dev_PH Block Block_Fxn
# Sex: 1  BioPattern: 1  NatMort
0.05	0.5	0.18	-1.714798	0.438	3	1	0	0	0	0	0	0 	0 # NatM_p_1_Fem_GP_1

# Sex: 1  BioPattern: 1  Growth
1	45	25.9422 	6.7812	10	0	-4	0	0	0 	0 	0 	0 	0 # L_at_Amin_Fem_GP_1
40 	250 	103.88831 	192	10 	0 	-4 	0 	0 	0 	0 	0 	0 	0 # L_at_Amax_Fem_GP_1
0.01 	1 	0.163024 	0.0676  0.8 	0 	-4 	0 	0 	0 	0 	0 	0 	0 # VonBert_K_Fem_GP_1
0 	15 	4.4375 		0.1 	0.8 	0 	-3 	0 	0 	0 	0 	0 	0 	0 # CV_young_Fem_GP_1
0	15 	7.8405	 	0.1 	0.8 	0 	-3 	0 	0 	0 	0 	0 	0 	0 # CV_old_Fem_GP_1

# Sex: 1  BioPattern: 1  WtLen
-3 	3 	0.00000708 3.661e-005 	0.8 	0 	-3 	0 	0 	0 	0 	0 	0 	0 # Wtlen_1_Fem_GP_1
-3 	5 	3.1115532 	2.90182 0.8 	0 	-3 	0 	0 	0 	0 	0 	0 	0 # Wtlen_2_Fem_GP_1

# Sex: 1  BioPattern: 1  Maturity&Fecundity
-3 	70 	47.2788 	47.1 	0.8 	0 	-3 	0 	0 	0 	0 	0 	0 	0 # Mat50%_Fem_GP_1
-3 	3 	-0.8912251 	-0.15 	0.8 	0 	-3 	0 	0 	0 	0 	0 	0 	0 # Mat_slope_Fem_GP_1
-3 	3 	1 	1 	0.8 	0 	-3 	0 	0 	0 	0 	0 	0 	0 # Eggs/kg_inter_Fem_GP_1
-3 	3 	1 	1	0.8 	0 	-3 	0 	0 	0 	0 	0 	0 	0 # Eggs/kg_slope_wt_Fem_GP_1

## MALE BIOLOGY
# Sex: 2  BioPattern: 1  NatMort
 0.05	0.5 	0.2347826	-1.449095	0.438 	3 	1 	0 	0 	0 	0 	0 	0 	0 # NatM_p_1_Mal_GP_1

# Sex: 2  BioPattern: 1  Growth-
1 	45 	26.0684 	6.7812	10 	0 	-1 	0 	0 	0 	0 	0 	0 	0 # L_at_Amin_Mal_GP_1
40 	250 	81.2440	 	192.446 10 	0 	-4 	0 	0 	0 	0 	0 	0 	0 # L_at_Amax_Mal_GP_1
0.01 	1.0 	0.186933 	0.067695 0.8 	0 	-4 	0 	0 	0 	0 	0 	0 	0 # VonBert_K_Mal_GP_1
0 	15 	4.1850 		0.1 	0.8 	0 	-3 	0 	0 	0 	0 	0 	0 	0 # CV_young_Mal_GP_1
0 	15 	8.5250	 	0.1 	0.8 	0 	-3 	0 	0 	0 	0 	0 	0 	0 # CV_old_Mal_GP_1

# Sex: 2  BioPattern: 1  WtLen
-3 	3 	0.00000867	3.661e-005	0.8 0 	-3 	0 	0 	0 	0 	0 	0 	0 # Wtlen_1_Mal_GP_1
-3 	5 	3.06242		2.90182 0.8 	0 	-3 	0 	0 	0	0 	0 	0 	0 # Wtlen_2_Mal_GP_1

#  Recruitment Distribution  
 #0 0 0 0 0 0 -4 0 0 0 0 0 0 0 # RecrDist_GP_1
 #0 0 0 0 0 0 -4 0 0 0 0 0 0 0 # RecrDist_Area_1
 #0 0 0 0 0 0 -4 0 0 0 0 0 0 0 # RecrDist_month_1

#  Cohort growth dev base
 0.1 	10 	1 	1 	1 	0 	-1 0 0 0 0 0 0 0 # CohortGrowDev

#  Movement
#  Age Error from parameters
#  catch multiplier
#  fraction female, by GP
 1e-006 0.999999 0.5 	0.5 	0.5 	0 	-99 0 0 0 0 0 0 0 # FracFemale_GP_1

#
#_no timevary MG parameters
#
#_seasonal_effects_on_biology_parms
 0 0 0 0 0 0 0 0 0 0 #_femwtlen1,femwtlen2,mat1,mat2,fec1,fec2,Malewtlen1,malewtlen2,L1,K
#_ LO HI INIT PRIOR PR_SD PR_type PHASE
#_Cond -2 2 0 0 -1 99 -2 #_placeholder when no seasonal MG parameters
#
3 #_Spawner-Recruitment; Options: 2=Ricker; 3=std_B-H; 4=SCAA; 5=Hockey; 6=B-H_flattop; 7=survival_3Parm; 8=Shepherd_3Parm; 9=RickerPower_3parm
0  # 0/1 to use steepness in initial equ recruitment calculation    ####6.44795 inital value prev.
0  #  future feature:  0/1 to make realized sigmaR a function of SR curvature
#_          LO            HI          INIT         PRIOR         PR_SD       PR_type      PHASE    env-var    use_dev   dev_mnyr   dev_mxyr     dev_PH      Block    Blk_Fxn #  parm_name
             3            15           7.5          10.3            10             0          1          0          0          0          0          0          0          0 # SR_LN(R0)
           0.2             1           0.9           0.7          0.05             1         -4          0          0          0          0          0          0          0 # SR_BH_steep
             0             2           0.6           0.8           0.8             0         -4          0          0          0          0          0          0          0 # SR_sigmaR
            -5             5             0             0             1             0         -4          0          0          0          0          0          0          0 # SR_regime
             0             0             0             0             0             0        -99          0          0          0          0          0          0          0 # SR_autocorr

#_no timevary SR parameters
1 #1 #do_recdev:  0=none; 1=devvector (R=F(SSB)+dev); 2=deviations (R=F(SSB)+dev); 3=deviations (R=R0*dev; dev2=R-f(SSB)); 4=like 3 with sum(dev2) adding penalty
1980 # first year of main recr_devs; early devs can preceed this era
2015 # last year of main recr_devs; forecast devs start in following year
1 #_recdev phase
 
1 # (0/1) to read 13 advanced options
-20 #_recdev_early_start (0=none; neg value makes relative to recdev_start)
1 # -4 #_recdev_early_phase
0 #_forecast_recruitment phase (incl. late recr) (0 value resets to maxphase+1)
1 #_lambda for Fcast_recr_like occurring before endyr+1
1968 #1966.8 #1980 #_last_yr_nobias_adj_in_MPD; begin of ramp
1973 #1981.4 #1985 #_first_yr_fullbias_adj_in_MPD; begin of plateau
2010.2 #2014 #_last_yr_fullbias_adj_in_MPD
2015 #2016 #_end_yr_for_ramp_in_MPD (can be in forecast to shape ramp, but SS sets bias_adj to 0.0 for fcast yrs)
 0.9 #_max_bias_adj_in_MPD (-1 to override ramp and set biasadj=1.0 for all estimated recdevs)
 0 #_period of cycles in recruitment (N parms read below)
-15 #min rec_dev
 15 #max rec_dev
 0 #_read_recdevs
#_end of advanced SR options
#
#_placeholder for full parameter lines for recruitment cycles
# read specified recr devs
#_Yr Input_value
#
# all recruitment deviations
#  1971R 1972R 1973R 1974R 1975R 1976R 1977R 1978R 1979R 1980R 1981R 1982R 1983R 1984R 1985R 1986R 1987R 1988R 1989R 1990R 1991R 1992R 1993R 1994R 1995R 1996R 1997R 1998R 1999R 2000R 2001R 2002F 2003F 2004F 2005F 2006F 2007F 2008F 2009F 2010F 2011F
#  0.152049 -0.0946753 0.110298 -0.178096 0.0435859 0.709985 -0.0130968 0.00421151 0.267748 0.165904 0.132445 -0.228699 -0.466715 -0.301659 0.402607 0.57651 0.23602 0.154297 -0.422341 0.555724 -0.653761 -0.244394 -0.987371 0.376023 -0.476265 0.408171 1.1255 -0.544831 -0.661744 0.160207 -0.307643 0 0 0 0 0 0 0 0 0 0
# implementation error by year in forecast:  0 0 0 0 0 0 0 0 0 0
#
#Fishing Mortality info 
0.2 # F ballpark
-2008 # F ballpark year (neg value to disable)
3 # F_Method:  1=Pope; 2=instan. F; 3=hybrid (hybrid is recommended)
4 # max F or harvest rate, depends on F_Method
# no additional F input needed for Fmethod 1
# if Fmethod=2; read overall start F value; overall phase; N detailed inputs to read
# if Fmethod=3; read N iterations for tuning for Fmethod 3
7  # N iterations for tuning F in hybrid method (recommend 3 to 7)
#
#_initial_F_parms; count = 0
#_ LO 	HI 	INIT 	PRIOR 	PR_SD  PR_type  PHASE
0	1	0.01	0.01	99	-1	-1	# F1
0	1	0.01	0.01	99	-1	-1	# F2
-1	1	0.01	0.01	99	-1	-1	# F3
0	1	0.01	0.01	99	-1	-1	# F4
0	1	0.01	0.01	99	-1	-1	# F5

# F rates by fleet
# Yr:  1971 1972 1973 1974 1975 1976 1977 1978 1979 1980 1981 1982 1983 1984 1985 1986 1987 1988 1989 1990 1991 1992 1993 1994 1995 1996 1997 1998 1999 2000 2001 2002 2003 2004 2005 2006 2007 2008 2009 2010 20116# seas:  1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1
# FISHERY 0 0.00209557 0.0105306 0.0106212 0.021529 0.0330468 0.0455477 0.059432 0.0750949 0.106874 0.145706 0.161229 0.179367 0.201025 0.227872 0.262861 0.310539 0.334347 0.351498 0.353889 0.337027 0.236475 0.240741 0.24773 0.259611 0.278475 0.22313 0.234471 0.244592 0.249677 0.249651 0.0181035 0.0321256 0.0415989 0.0478944 0.0522013 0.0553858 0.0580086 0.060369 0.062586 0.0646825
#
#_Q_setup for fleets with cpue or survey data
#_1:  fleet number
#_2:  link type: (1=simple q, 1 parm; 2=mirror simple q, 1 mirrored parm; 3=q and power, 2 parm; 4=mirror with offset, 2 parm)
#_3:  extra input for link, i.e. mirror fleet# or dev index number
#_4:  0/1 to select extra sd parameter
#_5:  0/1 for biasadj or not
#_6:  0/1 to float
#_survey: 4 Depletion is a depletion fleet
#_Q_setup(f,2)=0; add 1 to phases of all parms; only R0 active in new phase 1
#_fleet link link_info  extra_se   biasadj     float  #  fleetname
 1	1	0	0	0	0  #  F1
#2	1	0	0	0	0  #  F2
#3	1	0	0	0	0  #  F3
 4	1	0	0	0	0  #  F4
#5	1	0	0	0	0  #  F5
 6	1	0	0	0	0  #  S6
-9999 0 0 0 0 0	   

#_Q_parms(if_any);Qunits_are_ln(q)
#_          LO            HI          INIT         PRIOR         PR_SD       PR_type      PHASE    env-var    use_dev   dev_mnyr   dev_mxyr     dev_PH      Block    Blk_Fxn  #  parm_name
            -20             5             -5             0             1           0         1          0          0          0          0          0          0          0  #  LnQ_base_FISHERY(1)
 #          -7             5      	 0             0             1             0         -1          0          0          0          0          0          0          0  #  LnQ_base_FISHERY(2)
 #          -7             5             0             0             1             0         -1          0          0          0          0          0          0          0  #  LnQ_base_FISHERY(3)
            -20            5      	 -5             0             1             0        1          0          0          0          0          0          0          0  #  LnQ_base_FISHERY(4)
  #         -7             5             0             0             1             0         -1          0          0          0          0          0          0          0  #  LnQ_base_FISHERY(5)
            -20             5             -5             0             1             0        1          0          0          0          0          0          0          0  #  LnQ_base_Survey(6)
#_no timevary Q parameters
#
#_size_selex_patterns
#Pattern:_0; parm=0; selex=1.0 for all sizes
#Pattern:_1; parm=2; logistic; with 95% width specification
#Pattern:_5; parm=2; mirror another size selex; PARMS pick the min-max bin to mirror
#Pattern:_15; parm=0; mirror another age or length selex
#Pattern:_6; parm=2+special; non-parm len selex
#Pattern:_43; parm=2+special+2;  like 6, with 2 additional param for scaling (average over bin range)
#Pattern:_8; parm=8; New doublelogistic with smooth transitions and constant above Linf option
#Pattern:_9; parm=6; simple 4-parm double logistic with starting length; parm 5 is first length; parm 6=1 does desc as offset
#Pattern:_21; parm=2+special; non-parm len selex, read as pairs of size, then selex
#Pattern:_22; parm=4; double_normal as in CASAL
#Pattern:_23; parm=6; double_normal where final value is directly equal to sp(6) so can be >1.0
#Pattern:_24; parm=6; double_normal with sel(minL) and sel(maxL), using joiners
#Pattern:_25; parm=3; exponential-logistic in size
#Pattern:_27; parm=3+special; cubic spline 
#Pattern:_42; parm=2+special+3; // like 27, with 2 additional param for scaling (average over bin range)
#_discard_options:_0=none;_1=define_retention;_2=retention&mortality;_3=all_discarded_dead;_4=define_dome-shaped_retention
#_Pattern Discard Male Special
 24 2 0 0 # 1 F1
 24 2 0 0 # 2 F2
 24 2 0 0 # 3 F3
 24 2 0 0 # 4 F4
 24 2 0 0 # 5 F5
 24 0 0 0 # 6 SFBay
#
#_age_selex_patterns
#Pattern:_0; parm=0; selex=1.0 for ages 0 to maxage
#Pattern:_10; parm=0; selex=1.0 for ages 1 to maxage
#Pattern:_11; parm=2; selex=1.0  for specified min-max age
#Pattern:_12; parm=2; age logistic
#Pattern:_13; parm=8; age double logistic
#Pattern:_14; parm=nages+1; age empirical
#Pattern:_15; parm=0; mirror another age or length selex
#Pattern:_16; parm=2; Coleraine - Gaussian
#Pattern:_17; parm=nages+1; empirical as random walk  N parameters to read can be overridden by setting special to non-zero
#Pattern:_41; parm=2+nages+1; // like 17, with 2 additional param for scaling (average over bin range)
#Pattern:_18; parm=8; double logistic - smooth transition
#Pattern:_19; parm=6; simple 4-parm double logistic with starting age
#Pattern:_20; parm=6; double_normal,using joiners
#Pattern:_26; parm=3; exponential-logistic in age
#Pattern:_27; parm=3+special; cubic spline in age
#Pattern:_42; parm=2+special+3; // cubic spline; with 2 additional param for scaling (average over bin range)
#_Pattern Discard Male Special
 10 0 0 0 # 1 F1
 10 0 0 0 # 2 F2
 10 0 0 0 # 3 F3
 10 0 0 0 # 4 F4
 10 0 0 0 # 4 F5
 10 0 0 0 # SFBay
#
#_          LO            HI          INIT         PRIOR         PR_SD       PR_type      PHASE    env-var    use_dev   dev_mnyr   dev_mxyr     dev_PH      Block    Blk_Fxn  #  parm_name
### Size Selectivity: Bottom Trawl
#_LO 	HI 	INIT 	PRIOR     SD	PR_type PHASE   env-var use_dev dev_minyr dev_maxyr dev_stddev Block Block_Fxn
30	80	53.0	-60.0	0.05	0	2	0	0	0	0	0.5	0	0	#	p1 - Peak value			
-15.0	15.0	-3	-10.0	0.05	0	-3	0	0	0	0	0.5	0	0	#	p2 - Top logistic			
-5.0	10.0	5.5	-4.0	0.05	0	3	0	0	0	0	0.5	0	0	#	p3 - Ascending width			
-5.0	20.0	15	-4.0	0.05	0	3	0	0	0	0	0.5	0	0	#	p4 - Descending width			
-15.0	9.0	-15	-15.0	0.05	0	-3	0	0	0	0	0.5	0	0	#	p5 - Initial selectivity at first bin
-15.0	9.0	-999	-15.0	0.05	0	-3	0	0	0	0	0.5	0	0	#	p6 - Final selectivity at last bin

### Retention
0	120	54	43.2	0	0	-7	0	0	0	0	0.5	0	0	#	p1 - Inflection  (retention at L50)            
-15	15	1	0	0	0	-7	0	0	0	0	0.5	0	0	#	p2 - slope #changed from 2
-10	10	10	10	0	0	-1	0	0	1980	2008	0.5	0	0	#	p3 - Asymptotic retention (any value between 0 and 1)
-15	15	0	0	0	0	-3	0	0	0	0	0.5	0	0	#	p4 - Male offset to inflection (market related differnces?)

### Mortality
20	119	1	43.2	0	0	-4	0	0	0	0	0.5	0	0	#	p1 - Inflection              
-15	15	0.1	0	0	0	-3	0	0	0	0	0.5	0	0	#	p2 - slope
-15	15	0.5	0	0	0	-5	0	0	1980	2008	0.5	0	0	#	p3 - Asymptotic retention
-15	15	0	0	0	0	-3	0	0	0	0	0.5	0	0	#	p4 - Male offset to inflection

### Male Offset 
#-15	150	68	0	0	0	-6	0	0	0	0	0.5	0	0	#	p1 - size (age) at which a dogleg occurs (set to an integer at a bin boundary and do not estimate)             
#-15	15	0	0	0	0	-6	0	0	0	0	0.5	0	0	#	p2 - log(relative male selectivity) at minL or age=0
#-15	0	-0.1	0	0	0	-6	0	0	0	0	0.5	0	0	#	p3 - log(relative male selectivity) at the dogleg
#-15	15	-2	0	0	0	-6	0	0 	0	0	0.5	0	0	#	p4 - log(relative male selectivity) at maxL or max age.

#######################################################
######	Fleet 2: Gillnet	#######################

### Size Selectivity-
30	100.0	58.0	68.0	0.05	0	-2	0	0	0	0	0.5	0	0	#	p1 - Peak value 	###20.0	50.0	30.0	68.0	-1	0.05	-2	0	0	0	0	0.5	0	0	#	p1 - size at inflection	###    
-15.0	15.0	-5	-2.0	0.05	0	-3	0	0	0	0	0.5	0	0	#	p2 - Top logistic	###5.0	25.0	18.0	-2.0	-1	0.05	-2	0	0	0	0	0.5	0	0	#	p2 - width at 95% selex ######
-5.0	10.0	5	-4.0	0.05	0	-3	0	0	0	0	0.5	0	0	#	p3 - Ascending width			
-5.0	20.0	6	-4.0	0.05	0 	-3	0	0	0	0	0.5	0	0	#	p4 - Descending width			
-15.0	9.0	-15	-15.0	0.05	0	-3	0	0	0	0	0.5	0	0	#	p5 - Initial selectivity at first bin
-15.0	9.0	-999	-15.0	0.05	0	-3	0	0	0	0	0.5	0	0	#	p6 - Final selectivity at last bin

### Retention
0	120	52	43.2	0	0	-7	0	0	0	0	0.5	0	0	#	p1 - Inflection              
-15	15	1	0	0	0	-7	0	0	0	0	0.5	0	0	#	p2 - slope
-10	10	10	10	0	0	-1	0	0	1980	2008	0.5	0	0	#	p3 - Asymptotic retention
-15	15	0	0	0	0	-3	0	0	0	0	0.5	0	0	#	p4 - Male offset to inflection

### Mortality
20	119	1	43.2	0	0	-4	0	0	0	0	0.5	0	0	#	p1 - Inflection              
-15	15	0.1	0	0	0	-3	0	0	0	0	0.5	0	0	#	p2 - slope
-15	15	0.3	0	0	0	-5	0	0	1980	2008	0.5	0	0	#	p3 - Asymptotic retention
-15	15	0	0	0	0	-3	0	0	0	0	0.5	0	0	#	p4 - Male offset to inflection

### Male offset
#-15	150	60	0	0	0	-6	0	0	0	0	0.5	0	0	#	p1 - size (age) at which a dogleg occurs (set to an integer at a bin boundary and do not estimate)             
#-15	15	0	0	0	0	-6	0	0	0	0	0.5	0	0	#	p2 - log(relative male selectivity) at minL or age=0
#-15	15	-0.28	0	0	0	-6	0	0	0	0	0.5	0	0	#	p3 - log(relative male selectivity) at the dogleg
#-15	15	-0.28	0	0	0	-6	0	0	0	0	0.5	0	0	#	p4 - log(relative male selectivity) at maxL or max age.

#######################################################
######	Fleet 3: Hook and Line (Commercial)	#######

### Size Selectivity
30	90	56.211000	60.0	0.05	0	-2	0	0	0	0	0.5	0	0	#	p1 - Peak  ###20.0	50.0 30.0	68.0	-1	0.05	-2	0	0	0	0	0.5	0	0	#	p1 - size at inflection	### 
-15.0	15.0	-5.0	-5.0	0.05	0	-3	0	0	0	0	0.5	0	0	#	p2 - Top  ####5.0	25.0	18.0	-2.0	-1	0.05	-2	0	0	0	0	0.5	0	0	#	p2 - width at 95% selex ######
-5.0	10.0	5	3.0	0.05	0	-3	0	0	0	0	0.5	0	0	#	p3 - Ascending
-5.0	20.0	6.354280	5.0	0.05	0	-3	0	0	0	0	0.5	0	0	#	p4 - Descending
-15.0	9.0	-15	-15.0	0.05	0	-3	0	0	0	0	0.5	0	0	#	p5 - Initial
-15.0	9.0	-999	-15.0	0.05	0	-3	0	0	0	0	0.5	0	0	#	p6 - Final

### Retention
0	120	54	43.2	0	0	-7	0	0	0	0	0.5	0	0	#	p1 - Inflection              
-15	15	1	0	0	0	-7	0	0	0	0	0.5	0	0	#	p2 - slope
-10	10	10	10	0	0	-1	0	0	0	0	0.5	0	0	#	p3 - Asymptotic retention
-15	15	0	0	0	0	-3	0	0	0	0	0.5	0	0	#	p4 - Male offset to inflection

### Mortality
20	119	1	43.2	0	0	-4	0	0	0	0	0.5	0	0	#	p1 - Inflection              
-15	15	0.1	0	0	0	-3	0	0	0	0	0.5	0	0	#	p2 - slope
-15	15	0.1	0	0	0	-5	0	0	0	0	0.5	0	0	#	p3 - Asymptotic retention
-15	15	0	0	0	0	-3	0 	0	0	0 	0.5	0	0	#	p4 - Male offset to inflection

### Male offset
#-15	150	54	0	0	0	-6	0	0	0	0	0.5	0	0	#	p1 - size (age) at which a dogleg occurs (set to an integer at a bin boundary and do not estimate)             
#-15	15	0	0	0	0	-6	0	0	0	0	0.5	0 	0	#	p2 - log(relative male selectivity) at minL or age=0
#-15	15	-0.69	0	0	0	-6	0	0	0	0	0.5	0	0	#	p3 - log(relative male selectivity) at the dogleg
#-15	15	-2.3	0	0	0	-6	0	0	0	0	0.5	0	0	#	p4 - log(relative male selectivity) at maxL or max age.

#######################################################
######	Fleet 4: Recreational, CPFV	###############

### Size Selectivity
30	80	54.0	42.0	0.05	0	2	0	0	0	0	0.5	0	0	#	p1 - Peak
-15.0	15.0	-5.0	-2.0	0.05	0	-3	0	0	0	0	0.5	0	0	#	p2 - Top
-5.0	15.0	5	5.0	0.05	0	-3	0	0	0	0	0.5	0	0	#	p3 - Ascending
-5.0	20.0	15.0	6.0	0.05	0	3	0	0	0	0	0.5	0	0	#	p4 - Descending
-15.0	9.0	-15	-15.0	0.05	0	-3	0	0	0	0	0.5	0	0	#	p5 - Initial
-15.0	9.0	-999	-15.0	0.05	0	-3	0	0	0	0	0.5	0	0	#	p6 - Final

### Retention
0	120	54	43.2	0	0	-7	0	0	0	0	0.5	0	0	#	p1 - Inflection              
-15	15	1	0	0	0	-7	0	0	0	0	0.5	0	0	#	p2 - slope
-10	10	10	10	0	0	-1	0	0	0	0	0.5	0	0	#	p3 - Asymptotic retention
-15	15	0	0	0	0	-3	0	0	0	0	0.5	0	0	#	p4 - Male offset to inflection

### Mortality
20	119	1	43.2	0	0	-4	0	0	0	0	0.5	0	0	#	p1 - Inflection              
-15	15	0.1	0	0	0	-3	0	0	0 	0	0.5	0	0	#	p2 - slope
-15	15	0.1	0	0	0	-5	0	0	0	0	0.5	0	0	#	p3 - Asymptotic retention
-15	15	0	0	0	0	-3	0	0	0	0	0.5	0	0	#	p4 - Male offset to inflection

### Male offset
#-15	150	58	0	0	0	-6	0	0	0	0	0.5	0	0	#	p1 - size (age) at which a dogleg occurs (set to an integer at a bin boundary and do not estimate)             
#-15	15	0	0	0	0	-6	0	0	0	0	0.5	0	0	#	p2 - log(relative male selectivity) at minL or age=0
#-15	15	-0.2	0	0	0	-6	0	0	0	0	0.5	0	0	#	p3 - log(relative male selectivity) at the dogleg
#-15	15	-2.3	0	0	0	-6	0	0	0	0	0.5	0	0	#	p4 - log(relative male selectivity) at maxL or max age.

#######################################################
######	Fleet 5: Recreational, Other	###############

### Size Selectivity
30	80	52	65.0	0.05	0	2	0	0	0	0	0.5	0	0	#	PEAK	value
-15.0	15.0	-5	-5.0	0.05	0	-3	0	0	0	0	0.5	0	0	#	TOP	logistic
-5.0	10.0	6	5.0	0.05	0	3	0	0	0	0	0.5	0	0	#	Ascending
-5.0	20.0	15	6.0	0.05	0	3	0	0	0	0	0.5	0	0	#	Descending
-15.0	9.0	-15	-999	0.05	0	-3	0	0	0	0	0.5	0	0	#	INIT	logistic
-15.0	9.0	-999	-999	0.05	0	-3	0	0	0	0	0.5	0	0	#	FINAL	logistic

### Retention
0	120	54	43.2	0	0	-7	0	0	0	0	0.5	0	0	#	p1 - Inflection              
-15	15	1	0	0	0	-7	0	0	0	0	0.5	0	0	#	p2 - slope
-10	10	10	10	0	0	-1	0	0	0	0	0.5	0	0	#	p3 - Asymptotic retention
-15	15	0	0	0	0	-3	0	0	0	0	0.5	0	0	#	p4 - Male offset to inflection

### Mortality
20	119	1	43.2	0	0	-4	0	0	0	0	0.5	0	0	#	p1 - Inflection              
-15	15	0.1	0	0	0	-3	0	0	0	0	0.5	0	0	#	p2 - slope
-15	15	0.1	0	0	0	-5	0	0	0	0	0.5	0	0	#	p3 - Asymptotic retention
-15	15	0	0	0	0	-3	0	0	0	0	0.5	0	0	#	p4 - Male offset to inflection

### Male offset
#-15	150	54	0	0	0	-6	0	0	0	0	0.5	0	0	#	p1 - size (age) at which a dogleg occurs (set to an integer at a bin boundary and do not estimate)             
#-15	15	0	0	0	0	-6	0	0	0	0	0.5	0	0	#	p2 - log(relative male selectivity) at minL or age=0
#-15	15	-0.7	0	0	0	-6	0	0	0	0	0.5	0	0	#	p3 - log(relative male selectivity) at the dogleg
#-15	15	-0.7	0	0	0	-6	0	0	0	0	0.5	0	0	#	p4 - log(relative male selectivity) at maxL or max age.

#######################################################
######	F6: SF Bay Trawl Survey	###############
3.5	20	6	50	0	0 	4 	0	0	0	0	0.5	0	0	#	p1 - Peak value              
-15	15	-10	0	0 	0 	-4 	0 	0 	0 	0 	0.5 	0 	0 	# 	p2 - Top logistic
-15	15	15	0	0 	0 	-4 	0 	0 	0 	0 	0.5 	0 	0 	# 	p3 - Ascending width
0	5	2.5	0	0 	0 	6 	0 	0 	0 	0 	0.5 	0 	0 	# 	p4 - Descending width
-5	15	-999	0	0 	0 	-2 	0 	0 	0 	0 	0.5 	0 	0 	# 	p5 - Initial selectivity at first bin
-15	15	-999	0	0 	0	-2 	0 	0 	0 	0 	0.5 	0 	0 	# 	p6 - Final selectivity at last bin

# Age selectivity parameterization
#0	30	2	0	0.1	99	-1	0 0 0 0 0 0 0 # AgeSel_3P_1_Shrimp_Bycatch_3
#0	30	25	0	1	99	-1	0 0 0 0 0 0 0 # AgeSel_3P_1_Shrimp_Bycatch_3

# Age selectivity parameterization
#0	30	2	0	0.1	99	-1	0 0 0 0 0 0 0 # AgeSel_3P_1_Shrimp_Bycatch_3
#0	30	25	0	1	99	-1	0 0 0 0 0 0 0 # AgeSel_3P_1_Shrimp_Bycatch_3

# Age selectivity parameterization, SFBay Trawl
#0	30	0	0	0.1	99	-1	0 0 0 0 0 0 0 # AgeSel_3P_1_Shrimp_Bycatch_3
#0	30	2	0	1	99	-1	0 0 0 0 0 0 0 # AgeSel_3P_1_Shrimp_Bycatch_3

#_timevary selex parameters

#
0   #  use 2D_AR1 selectivity(0/1):  experimental feature
#_no 2D_AR1 selex offset used
#
# Tag loss and Tag reporting parameters go next
0  # TG_custom:  0=no read and autogen if tag data exist; 1=read
#_Cond -6 6 1 1 2 0.01 -4 0 0 0 0 0 0 0  #_placeholder if no parameters
#
# no timevary parameters
#
#
# Input variance adjustments factors: 
 #_1=add_to_survey_CV
 #_2=add_to_discard_stddev
 #_3=add_to_bodywt_CV
 #_4=mult_by_lencomp_N
 #_5=mult_by_agecomp_N
 #_6=mult_by_size-at-age_N
 #_7=mult_by_generalized_sizecomp
#_Factor  Fleet  Value
4	1	0.334
4	2	0.3514  
4	3	0.0675
4	4	0.1135
4	5	0.0958
4	6	0.0211
5	1	0.22794
-9999   1    0  # terminator


#
7 #_maxlambdaphase
1 #_sd_offset; must be 1 if any growthCV, sigmaR, or survey extraSD is an estimated parameter
# read 3 changes to default Lambdas (default value is 1.0)
# Like_comp codes:  1=surv; 2=disc; 3=mnwt; 4=length; 5=age; 6=SizeFreq; 7=sizeage; 8=catch; 9=init_equ_catch; 
# 10=recrdev; 11=parm_prior; 12=parm_dev; 13=CrashPen; 14=Morphcomp; 15=Tag-comp; 16=Tag-negbin; 17=F_ballpark; 18=initEQregime
#like_comp fleet  phase  value  sizefreq_method
# cpue
1	1	1	1	1
1	4	1	1	1
1	6	1	1	1
#disc
2	1	1	1	1
2	2	1	1	1
2	3	1	1	1
2	4	1	1	1
2	5	1	1	1
#length
4	1	1	1	1
4	2	1	1	1
4	3	1	1	1
4	4	1	1	1
4	5	1	1	1
4	6	1	0	1
#age
5	1	1	1	1
#5	2	1	1	1
5	3	1	1	1
#5	4	1	0	1
#5	5	1	0	1
#catch
8	1	1	1	1
8	2	1	1	1
8	3	1	1	1
8	4	1	1	1
8	5	1	1	1
# Eq catch
9	1	1	0	1
9	2	1	0	1
9	3	1	0	1
9	4	1	0	1
9	5	1	0	1
#prior
9	1	1	0	1
-9999  1  1  1  1  #  terminator
#

0 #1 # (0/1) read specs for more stddev reporting 
 #1 1 -1 5 1 5 1 -1 5 # selex_fleet, 1=len/2=age/3=both, year, N selex bins, 0 or Growth pattern, N growth ages, 0 or NatAge_area(-1 for sum), NatAge_yr, N Natages
 #5 15 25 35 43 # vector with selex std bins (-1 in first bin to self-generate)
 #1 2 14 26 40 # vector with growth std ages picks (-1 in first bin to self-generate)
 #1 2 14 26 40 # vector with NatAge std ages (-1 in first bin to self-generate)
999

